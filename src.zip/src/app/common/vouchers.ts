export const vouchers = [
    {name : "0FF50",discount:10},
    {name : "YKD40",discount:5},
    {name : "0F3T7",discount:30},
    {name : "T5650",discount:20},
    {name : "8FG43",discount:15},
    {name : "5KUTY",discount:25},
    {name : "TYS35",discount:30},
    {name : "45GAE",discount:10},
]