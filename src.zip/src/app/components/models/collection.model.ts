export class Collection {
	public name: string;
}