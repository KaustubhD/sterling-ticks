export class ProductListModel{
    public name: String = '';
    public brand: string= '' ;
    public starRating: number = 0;
    public price: number = 999;
    public img: string = '';
	public modelNo: string='';
}