export class Strap{
   public material: string;
   public color: string;
 }