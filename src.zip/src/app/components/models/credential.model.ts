export class CredentialModel{
    public username: String='';
    public password: String='';
}