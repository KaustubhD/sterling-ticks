export class Casing{
   public size: number;
   public shape: string;
   public material: string;
   public color: string;
}