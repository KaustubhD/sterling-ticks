export class Brand{
    public name: string = '';
    public imageUrl : string = '';
    public shortDesc: string = '';
}