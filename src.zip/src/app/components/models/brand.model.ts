export class Brand{
    public name: string='';
    public description: string='';
}