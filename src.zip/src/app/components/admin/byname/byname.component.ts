import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-byname',
  templateUrl: './byname.component.html',
  styleUrls: ['./byname.component.css']
})
export class BynameComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
