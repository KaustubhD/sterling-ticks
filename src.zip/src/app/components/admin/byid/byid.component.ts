import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-byid',
  templateUrl: './byid.component.html',
  styleUrls: ['./byid.component.css']
})
export class ByidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
